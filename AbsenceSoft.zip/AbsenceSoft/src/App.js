import React from 'react';
import Search from './components/searchbar';
//import Results from './components/RandomUserResults';

function App() {
  return (
    <div className="App">
      <Search />
    </div>
  );
}

export default App;
