const request = require('request');

var getData = function() {
  return new Promise(function(resolve, reject){
    request("https://randomuser.me/api/?results=100", function(err, res, body){
      if(err)
      {
        reject(err);
        //console.log(err)
      }
      else{
        resolve(JSON.parse(body));
        //console.log(JSON.parse(body));
      }

    });
  });
  }

module.exports.getData = getData;
