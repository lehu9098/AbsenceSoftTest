import React, {Component} from 'react';
import '../index.css'

class Search extends Component{
  getAPI(){ //gets all the random 100 people and sorts alphabetically
    let namesArr;
    let getAPI = require('../APIcall.js');
    getAPI.getData().then((result) => {
      namesArr = result.results;
      namesArr.sort(function(a,b){
        let nameA=a.name.last.toLowerCase(), nameB=b.name.last.toLowerCase();
        if (nameA < nameB) //sort string ascending
        {
          return -1
        }
        if (nameA > nameB){
          return 1
        }
        return 0 //default return value (no sorting)
      })
      this.setState({sortedArr: namesArr})
    })
  }
  componentDidMount()
  {
      this.getAPI();
  }
  state = {
      sortedArr: [],
      input: "",
      tempArray: [],
      shower: null,
      showSingle: false,
      userInfo: ""
    }
  changes = (e) => {
    let tempArr = [];
    let input = e.target.value;
    if(input.length >= 3 ){
      this.state.sortedArr.forEach(person => {
          if(person.name.last.toLowerCase().match(input.toLowerCase()) || person.phone.match(input.toLowerCase()))
          {
            if(tempArr.length < 10)
            {
              tempArr.push(person)
              this.setState({shower: true})
            }
          }
          else {
            if(tempArr.length === 0){
              this.setState({shower: false})
            }
          }
      })

      this.setState({tempArray: tempArr})
    }
    else
    {
      this.setState({shower: null, showSingle: false})

    }
  }
  showPerson = (first, last, phone, picture, e)  => {
    this.setState({userInfo: {first: first, last: last, phone: phone, picture: picture}, showSingle: true, shower: null})
    console.log(this.state.userInfo)
  }
  render(){
    let show = this.state.shower;
    let boxDisplay
    let userShow;
    if(show){
      userShow = this.state.tempArray.map(person => {
        return (<div className="listDisplay"><div onClick={(e) => this.showPerson(person.name.first,person.name.last,  person.phone, person.picture.thumbnail, e)}><img src={person.picture.thumbnail} alt={this.state.userInfo.first} width="25px" height="25px" className="thumb"/>  {person.name.first} {person.name.last} {person.phone}</div></div>)})
        }
    if(show === false){
          userShow = <div className="listDisplay"><button>No results were found</button></div>
      }
      if(this.state.showSingle)
      {
        boxDisplay = <div className="boxDisplay">
          <img src={this.state.userInfo.picture} alt={this.state.userInfo.first} className="spacing"/>
          <h3 className="spacing">{this.state.userInfo.first} {this.state.userInfo.last}</h3>
          <h4 className="spacing" >{this.state.userInfo.phone}</h4></div>
      }
    return(
      <div className="box">
        <div className="styledBox">
        <input type="text" list="names" placeholder="Enter the last name or phone number" onKeyUp={this.changes}></input>
          <div className="scrollable">{userShow}</div>
          {boxDisplay}
        </div>
      </div>
    )
  }
}
export default Search;
